import numpy as np
import math
from omok import OmokState

MAX_DEPTH = 2  # 탐색 깊이
BOARD_SIZE = 19 
DIRECTIONS = [(1, 0), (0, 1), (1, 1), (1, -1)]  # 오목의 방향
WIN_SCORE = 100000  # 승리 점수
FOUR_SCORE = 10000  # 4개의 돌 연속 점수
THREE_SCORE = 1000  # 3개의 돌 연속 점수
TWO_SCORE = 100  # 2개의 돌 연속 점수

def get_candidate_moves(state: OmokState, radius=2):
# 후보수 생성 함수
    if state.num_stones == 0: 
        center = BOARD_SIZE // 2
        return [(center, center)]
    
    stones = np.argwhere(state.game_board != 0)  
    candidates = set()  
    
    for y, x in stones:
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                ny, nx = y + dy, x + dx

                if 0 <= ny < BOARD_SIZE and 0 <= nx < BOARD_SIZE and state.is_valid_position(nx, ny):
                    candidates.add((ny, nx))
    
    candidates = list(candidates)
    
    if len(candidates) > 30:
        candidates = sorted(candidates, 
                            key=lambda pos: evaluate_move(state, pos[0], pos[1]), 
                            reverse=True)[:30]
    
    return candidates

def evaluate_move(state: OmokState, y, x):
    # 평가 점수 계산
    player = state.turn
    opponent = -player
    score = 0
    board = state.game_board.copy()
    
    board[y, x] = player
    if check_win(board, y, x, player):
        return WIN_SCORE
    
    for dy, dx in DIRECTIONS:
        score += calculate_pattern_score(board, y, x, player, dy, dx)
    
    board[y, x] = opponent
    if check_win(board, y, x, opponent):
        return WIN_SCORE * 0.9  # 방어는 공격보다 우선순위가 낮음
    
    for dy, dx in DIRECTIONS:
        score += calculate_pattern_score(board, y, x, opponent, dy, dx) * 0.8
    
    board[y, x] = 0  
    return score

def calculate_pattern_score(board, y, x, player, dy, dx):

    score = 0
    line = []
    
    for i in range(-5, 6):
        ny, nx = y + i*dy, x + i*dx
        if 0 <= ny < BOARD_SIZE and 0 <= nx < BOARD_SIZE:
            line.append(board[ny, nx])
        else:
            line.append(None)
    
    for start in range(1, 7):
        window = line[start:start+5]
        if None in window:
            continue
        
        stone_count = window.count(player)
        empty_count = window.count(0)
        
        left_open = start-1 >= 0 and line[start-1] == 0
        right_open = start+5 < len(line) and line[start+5] == 0
        both_open = left_open and right_open
        
        if stone_count == 4 and empty_count == 1:
            score += FOUR_SCORE * (1.5 if both_open else 1)
        elif stone_count == 3 and empty_count == 2:
            score += THREE_SCORE * (1.5 if both_open else 1)
        elif stone_count == 2 and empty_count == 3:
            score += TWO_SCORE * (1.2 if both_open else 1)
    
    return score

def check_win(board, y, x, player):
    for dy, dx in DIRECTIONS:
        count = 1
        
        for direction in [-1, 1]:
            ny, nx = y, x
            for _ in range(4):
                ny += dy * direction
                nx += dx * direction
                if 0 <= ny < BOARD_SIZE and 0 <= nx < BOARD_SIZE and board[ny, nx] == player:
                    count += 1
                else:
                    break
        
        # 5개의 돌이 연속되면 승리
        if count >= 5:
            return True
    
    return False

def evaluate_board(state: OmokState):
    status = state.check_status()
    if status is not None:
        if status == 1:  # 흑돌 승리
            return WIN_SCORE
        elif status == 2:  # 백돌 승리
            return -WIN_SCORE
        return 0  # 무승부
    
    board = state.game_board
    player = state.turn
    score = 0
    
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            if board[y, x] == 0:
                continue
            
            stone = board[y, x]
            for dy, dx in DIRECTIONS:
                count = 1
                open_ends = 0
                
                for dir_mul in [1, -1]:
                    ny, nx = y + dy * dir_mul, x + dx * dir_mul
                    while 0 <= ny < BOARD_SIZE and 0 <= nx < BOARD_SIZE:
                        if board[ny, nx] == stone:
                            count += 1
                        elif board[ny, nx] == 0:
                            open_ends += 1
                            break
                        else:
                            break
                        ny += dy * dir_mul
                        nx += dx * dir_mul
                
                value = 0
                if count >= 5:
                    value = WIN_SCORE
                elif count == 4:
                    value = FOUR_SCORE * (1 + 0.5 * open_ends)
                elif count == 3:
                    value = THREE_SCORE * (1 + 0.5 * open_ends)
                elif count == 2:
                    value = TWO_SCORE * (1 + 0.5 * open_ends)
                
                score += value if stone == player else -value * 0.9
    
    return score

def alpha_beta(state, depth, alpha, beta, maximizing):
# Alpha-Beta 가지치기
    if depth == 0 or state.check_status() is not None:
        return None, evaluate_board(state)
    
    moves = get_candidate_moves(state)
    if not moves:
        return None, 0
    
    best_move = None
    best_val = float('-inf') if maximizing else float('inf')
    
    for y, x in moves:
        
        board_copy, turn_copy = state.game_board.copy(), state.turn
        history_copy, stones_copy = state.history.copy(), state.num_stones
        state.update(x, y)
        
        # 재귀 탐색
        _, val = alpha_beta(state, depth - 1, alpha, beta, not maximizing)
        
        state.game_board, state.turn = board_copy, turn_copy
        state.history, state.num_stones = history_copy, stones_copy
        
        # 최선의 수 업데이트
        if (maximizing and val > best_val) or (not maximizing and val < best_val):
            best_val = val
            best_move = (y, x)
        
        if maximizing:
            alpha = max(alpha, best_val)
            if beta <= alpha:
                break
        else:
            beta = min(beta, best_val)
            if beta <= alpha:
                break

    return best_move, best_val

def find_critical_move(state, player):

    board = state.game_board
    
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            if not state.is_valid_position(x, y):
                continue
            
            board[y, x] = player
            if check_win(board, y, x, player):
                board[y, x] = 0
                return y, x
            board[y, x] = 0
    
    return None

def act(state: OmokState):
    print(state.history)

    if state.num_stones == 0:
        while True:
            y, x = np.random.randint(BOARD_SIZE), np.random.randint(BOARD_SIZE)
            if state.is_valid_position(x, y):
                return y, x
    
    win_move = find_critical_move(state, state.turn)
    if win_move:
        return win_move
    
    block_move = find_critical_move(state, -state.turn)
    if block_move:
        return block_move
    
    try:
        best_move, _ = alpha_beta(state, MAX_DEPTH, float('-inf'), float('inf'), True)
        if best_move:
            return best_move
    except:
        candidates = get_candidate_moves(state)
        if candidates:
            return max(candidates, key=lambda pos: evaluate_move(state, pos[0], pos[1]))
    
    while True:
        y, x = np.random.randint(BOARD_SIZE), np.random.randint(BOARD_SIZE)
        if state.is_valid_position(x, y):
            return y, x
